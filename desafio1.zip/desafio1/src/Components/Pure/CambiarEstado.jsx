import React, {Component} from 'react'
import PropTypes from 'prop-types';
import { Contacto } from '../../Models/Contacto.class';


export class CambiarEstado extends Component {

    constructor(props) {
        super(props);
        this.state = {
            contacto: this.props.contacto,
      }
    }

    cambiarEstadoModelo = () => {
        this.setState({contacto : new Contacto(
            this.state.contacto.nombre,
            this.state.contacto.apellido,
            this.state.contacto.email,
            (this.state.contacto.conectado ? false : true))})
        console.log(this.contacto.conectado)
    }

  render () {
    return (<div>
        <h1>Nombre: {this.state.contacto.nombre}</h1>
        <h1>Apellido: {this.state.contacto.apellido}</h1>
        <h1>Email: {this.state.contacto.email}</h1>
        <h1>
          Estado actual:{" "}
          {this.state.contacto.conectado ? "Contacto En Línea" : "Contacto No Disponible"}
        </h1>
    <button onClick={() => this.cambiarEstadoModelo()}>Cambiar estado del contacto</button>
    </div>);
    }

  
}

CambiarEstado.propTypes = {
    contacto: PropTypes.instanceOf(Contacto)
}


export default CambiarEstado