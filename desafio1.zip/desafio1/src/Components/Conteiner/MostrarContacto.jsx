import React from 'react'
import CambiarEstado from "../Pure/CambiarEstado";
import {Contacto} from '../../Models/Contacto.class'

export default function mostrarContacto() {

    const contacto = new Contacto('Pedro', 'Juarez', 'pedroJuarez@gmail.com', false)

  return (
    <CambiarEstado contacto={ contacto }></CambiarEstado>
  )
}
