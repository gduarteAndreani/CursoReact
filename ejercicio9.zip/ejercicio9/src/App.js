import logo from './logo.svg';
import './App.css';
import Tabla from './Components/Containers/tabla';

function App() {
  return (
    <Tabla></Tabla>
  );
}

export default App;
