import React, {useState} from 'react'
import Contacto from '../Pure/contacto'
import ContactoForm from '../Pure/Forms/contactoForm'

const Tabla = () => {

    const [contactos, setcontactos] = useState([])

    function eliminarContacto(contacto){
        const posicion = contactos.indexOf(contacto);
        let newContactos = contactos;
        newContactos.splice(posicion, 1);
        setcontactos = newContactos;
    }


    function agregarContacto(nuevoContacto){
        contactos.push(nuevoContacto);
        let nuevosContactos = contactos;
        setcontactos = nuevosContactos;
    }

  return (
    <div>{ contactos.map((contacto) => {
        return (<Contacto 
            contactoParam={contacto} 
            eliminar={eliminarContacto}>
            </Contacto>)
    
    }) }
    <ContactoForm agregarContacto={agregarContacto}></ContactoForm>
    </div>
  )
}

export default Tabla;