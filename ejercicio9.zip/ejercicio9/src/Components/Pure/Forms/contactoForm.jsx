import React, {useRef} from 'react'
import PropTypes from 'prop-types'
import {Contacto} from '../../../Models/contacto.class';

const ContactoForm = ({agregarContacto}) => {

    const nombre = useRef('');
    const apellido = useRef('');
    const direccion = useRef('');
    const telefono = useRef('');

    function agregar(c){
        c.preventDefault();
        const newContacto = new Contacto(
            nombre.current.value,
            apellido.current.value,
            direccion.current.value,
            telefono.current.value,
            true
        )
        agregarContacto(newContacto)
    }

  return (
    <form onSubmit={agregar}>
        <input ref={nombre} id='nombreForm' type='text' className='form-control' required/>
        <input ref={apellido} id='apellidoForm' type='text' className='form-control' required/>
        <input ref={direccion} id='direccionForm' type='text' className='form-control' required/>
        <input ref={telefono} id='telefonoForm' type='text' className='form-control' required/>
    <button type='submit' className='btn'></button>
    </form>
  )
}

ContactoForm.propTypes = {
    agregarContacto: PropTypes.func.isRequired
}

export default ContactoForm;