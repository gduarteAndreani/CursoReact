import React, {useState} from 'react'
import PropTypes from 'prop-types'

const Contacto = ({contactoParam, eliminar}) => {

const [contacto, setContacto] = useState(contactoParam)
const [estado, setEstado] = useState(contacto.estado)

function cambiarEstado(){
    setEstado = estado ? false : true;
}

  return (
    <td>
        <tr>Nombre: {contacto.nombre}</tr>
        <tr>Apellido: {contacto.apellido}</tr>
        <tr>Numero: {contacto.numero}</tr>
        <tr>Direccion: {contacto.direccion}</tr>
        <tr>Estado: {estado ? "conectado" : "desconectado"}</tr>
        <button onClick={() =>cambiarEstado()}>Cambiar estado</button>
        <button onClick={() => eliminar(contacto)}>Eliminar Contacto</button>
    </td>
  )
}

Contacto.propTypes = {
    contactoParam: PropTypes.instanceOf(Contacto).isRequired,
    eliminar: PropTypes.func.isRequired
}

export default Contacto;