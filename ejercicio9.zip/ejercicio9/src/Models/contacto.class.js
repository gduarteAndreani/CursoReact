export class Contacto {
    nombre = '';
    apellido = '';
    direccion = '';
    telefono = '';
    estado = null;

    constructor(nombre, apellido, direccion, telefono){
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.telefono = telefono;
        this.estado = true;
    }
}
